<?php
$usuarioDigitado = $_POST['usuario'];
$senhaDigitada = $_POST['senha'];
echo "Usuário = ";
echo $usuarioDigitado;
echo "<br>";
echo "Senha = ".$senhaDigitada;
?>